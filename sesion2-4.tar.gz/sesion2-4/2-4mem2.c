#include <stdio.h>
int main() {
  int *p = NULL; /* Pointers should be initialized to NULL */

  printf("%d\n", *p);
}