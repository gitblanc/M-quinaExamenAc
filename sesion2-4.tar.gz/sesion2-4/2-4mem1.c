int main()
{
  int *p = (int *)0x00000020;

  *p = 1234;
}
