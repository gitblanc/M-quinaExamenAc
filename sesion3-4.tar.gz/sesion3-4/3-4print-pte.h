#pragma once

void print_virtual_physical_pte(void *virtual_addr, char *title);